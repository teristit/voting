# services/notification_service.py
import requests
from config import Config

def send_notification(chat_id: int, message: str) -> bool:
    """
    Отправляет уведомление через Telegram Bot API.
    Используется для системных событий.
    """
    if not Config.TELEGRAM_BOT_TOKEN:
        print("[Notify] TELEGRAM_BOT_TOKEN not set.")
        return False

    url = f"https://api.telegram.org/bot{Config.TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": chat_id, "text": message, "parse_mode": "HTML"}

    try:
        resp = requests.post(url, json=payload)
        if resp.status_code == 200:
            print(f"[Notify] Sent to {chat_id}")
            return True
        print(f"[Notify] Failed ({resp.status_code}): {resp.text}")
        return False
    except Exception as e:
        print(f"[Notify] Error: {e}")
        return False
