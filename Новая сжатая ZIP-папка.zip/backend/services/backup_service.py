import os
import subprocess
from datetime import datetime
from config import Config

def create_backup() -> str | None:
    """
    Создаёт резервную копию базы данных PostgreSQL.
    Возвращает путь к файлу, если успешно.
    """
    if not Config.BACKUP_ENABLED:
        print("[Backup] Backup is disabled by configuration.")
        return None

    backup_dir = os.path.join(os.getcwd(), "backups")
    os.makedirs(backup_dir, exist_ok=True)

    filename = f"smart_bonus_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sql"
    filepath = os.path.join(backup_dir, filename)

    db_url = Config.SQLALCHEMY_DATABASE_URI
    try:
        subprocess.run(
            ["pg_dump", db_url, "-f", filepath],
            check=True
        )
        print(f"[Backup] Created: {filepath}")
        return filepath
    except Exception as e:
        print(f"[Backup] Error: {e}")
        return None
