from datetime import datetime
from extensions import db
from models.audit_log import AuditLog

def log_action(
    user_id: int | None,
    action: str,
    details: dict | None = None,
    session_id: int | None = None,
    ip_address: str | None = None,
    user_agent: str | None = None
):
    """
    Записывает действие пользователя в таблицу audit_log.
    """
    try:
        log = AuditLog(
            user_id=user_id,
            action=action,
            details=details,
            session_id=session_id,
            ip_address=ip_address,
            user_agent=user_agent,
            timestamp=datetime.utcnow(),
        )
        db.session.add(log)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"[Audit] Error logging action: {e}")
