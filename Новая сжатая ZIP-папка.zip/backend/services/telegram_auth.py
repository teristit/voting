# services/telegram_auth.py
import hashlib
import hmac
import urllib.parse
import json
from config import Config

def verify_telegram_init_data(init_data: str) -> dict | None:
    """
    Проверяет подпись initData, полученного из Telegram WebApp.
    Возвращает словарь с user-данными при успехе, иначе None.
    """
    try:
        parsed_data = dict(urllib.parse.parse_qsl(init_data))
        hash_to_check = parsed_data.pop("hash")
        data_check_string = "\n".join([f"{k}={v}" for k, v in sorted(parsed_data.items())])

        secret_key = hmac.new(
            b"WebAppData",
            Config.TELEGRAM_BOT_TOKEN.encode(),
            hashlib.sha256
        ).digest()

        calculated_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

        if calculated_hash != hash_to_check:
            return None

        user_json = parsed_data.get("user")
        if user_json:
            return json.loads(user_json)
        return None

    except Exception as e:
        print(f"[TelegramAuth] Verification failed: {e}")
        return None
