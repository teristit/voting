from extensions import db
from datetime import datetime


class BonusParameters(db.Model):
    __tablename__ = 'bonus_parameters'

    param_id = db.Column(db.BigInteger, primary_key=True)
    session_id = db.Column(db.BigInteger, db.ForeignKey('sessions.session_id', ondelete='CASCADE'), nullable=False)
    average_weekly_revenue = db.Column(db.Numeric(15, 2))
    participation_multiplier = db.Column(db.Numeric(5, 4))
    total_weekly_bonus = db.Column(db.Numeric(15, 2))
    participants_info = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    session = db.relationship('Session', back_populates='bonus_parameters')
