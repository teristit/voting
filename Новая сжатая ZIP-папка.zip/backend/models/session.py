from extensions import db
from datetime import datetime


class Session(db.Model):
    __tablename__ = 'sessions'

    session_id = db.Column(db.BigInteger, primary_key=True)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    active = db.Column(db.Boolean, default=True)
    auto_participants = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    closed_at = db.Column(db.DateTime)

    participants = db.relationship('SessionParticipant', back_populates='session', cascade='all, delete-orphan')
    votes = db.relationship('Vote', back_populates='session', cascade='all, delete-orphan')
    bonus_parameters = db.relationship('BonusParameters', back_populates='session', cascade='all, delete-orphan')
    results = db.relationship('Result', back_populates='session', cascade='all, delete-orphan')

    def __repr__(self):
        return f"<Session {self.session_id} {self.start_date}–{self.end_date}>"



class SessionParticipant(db.Model):
    __tablename__ = 'session_participants'

    participant_id = db.Column(db.BigInteger, primary_key=True)
    session_id = db.Column(db.BigInteger, db.ForeignKey('sessions.session_id', ondelete='CASCADE'), nullable=False)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id', ondelete='CASCADE'), nullable=False)
    can_vote = db.Column(db.Boolean, default=True)
    can_receive_votes = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(20), default='active', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    session = db.relationship('Session', back_populates='participants')
    user = db.relationship('User', back_populates='sessions')

    __table_args__ = (db.UniqueConstraint('session_id', 'user_id', name='uq_session_user'),)
