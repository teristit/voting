from extensions import db
from datetime import datetime
import uuid


class AuthSession(db.Model):
    __tablename__ = 'auth_session'

    session_id = db.Column(db.Uuid, primary_key=True, default=uuid.uuid4)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id', ondelete='CASCADE'), nullable=False)
    token_hash = db.Column(db.String(255), nullable=False, index=True)
    device_info = db.Column(db.JSON)
    ip_address = db.Column(db.String(64))
    expires_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', back_populates='auth_session')


class RevokedToken(db.Model):
    __tablename__ = 'revoked_tokens'

    token_hash = db.Column(db.String(255), primary_key=True)
    user_id = db.Column(db.BigInteger, nullable=False)
    revoked_at = db.Column(db.DateTime, default=datetime.utcnow)
    reason = db.Column(db.String(100))
