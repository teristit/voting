from extensions import db
from datetime import datetime


class AuditLog(db.Model):
    __tablename__ = 'audit_log'

    log_id = db.Column(db.BigInteger, primary_key=True)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id', ondelete='SET NULL'))
    action = db.Column(db.String(100), nullable=False)
    details = db.Column(db.JSON)
    session_id = db.Column(db.BigInteger, db.ForeignKey('sessions.session_id', ondelete='SET NULL'))
    ip_address = db.Column(db.String(64))
    user_agent = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
