from extensions import db
from datetime import datetime


class Vote(db.Model):
    __tablename__ = 'votes'

    vote_id = db.Column(db.BigInteger, primary_key=True)
    session_id = db.Column(db.BigInteger, db.ForeignKey('sessions.session_id', ondelete='CASCADE'), nullable=False)
    voter_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id', ondelete='CASCADE'), nullable=False)
    target_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id', ondelete='CASCADE'), nullable=False)
    score = db.Column(db.SmallInteger, nullable=False)
    modified_by_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    voter = db.relationship('User', foreign_keys=[voter_id], back_populates='votes_given')
    target = db.relationship('User', foreign_keys=[target_id], back_populates='votes_received')
    session = db.relationship('Session', back_populates='votes')

    __table_args__ = (db.UniqueConstraint('session_id', 'voter_id', 'target_id', name='uq_vote_unique'),)
