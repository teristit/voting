from extensions import db
from datetime import datetime


class Result(db.Model):
    __tablename__ = 'results'

    result_id = db.Column(db.BigInteger, primary_key=True)
    session_id = db.Column(db.BigInteger, db.ForeignKey('sessions.session_id', ondelete='CASCADE'), nullable=False)
    user_id = db.Column(db.BigInteger, db.ForeignKey('users.user_id', ondelete='CASCADE'), nullable=False)
    average_score = db.Column(db.Numeric(5, 2))
    rank = db.Column(db.Integer)
    total_bonus = db.Column(db.Numeric(15, 2))
    votes_received = db.Column(db.Integer)
    calculation_details = db.Column(db.JSON)
    calculated_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', back_populates='results')
    session = db.relationship('Session', back_populates='results')

    __table_args__ = (db.UniqueConstraint('session_id', 'user_id', name='uq_result_session_user'),)
