import json
from flask_jwt_extended import decode_token

def test_telegram_login(client, monkeypatch):
    # Подменяем верификацию Telegram
    monkeypatch.setattr("services.telegram_auth.verify_telegram_init_data", lambda x: {
        "id": 12345, "first_name": "TestUser", "username": "tester"
    })

    response = client.post("/api/v1/auth/telegram", json={"init_data": "fake"})
    data = response.get_json()

    assert response.status_code == 200
    assert "token" in data
    token_data = decode_token(data["token"])
    assert "sub" in token_data

def test_logout(client, monkeypatch):
    # Авторизуемся
    monkeypatch.setattr("services.telegram_auth.verify_telegram_init_data", lambda x: {
        "id": 12345, "first_name": "TestUser"
    })
    login = client.post("/api/v1/auth/telegram", json={"init_data": "fake"}).get_json()
    token = login["token"]

    # Выходим
    response = client.post(
        "/api/v1/auth/logout",
        headers={"Authorization": f"Bearer {token}"}
    )
    assert response.status_code == 200
