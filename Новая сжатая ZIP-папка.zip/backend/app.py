# app.py
from flask import Flask, jsonify
from flask_cors import CORS
from extensions import db, migrate, jwt
from config import Config

from routes import (
    auth_bp, users_bp, sessions_bp,
    participants_bp, votes_bp, results_bp,
    settings_bp, audit_bp
)

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    CORS(app)
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)

    # Регистрация всех маршрутов
    app.register_blueprint(auth_bp, url_prefix="/api/v1/auth")
    app.register_blueprint(users_bp, url_prefix="/api/v1/users")
    app.register_blueprint(sessions_bp, url_prefix="/api/v1/sessions")
    app.register_blueprint(participants_bp, url_prefix="/api/v1/participants")
    app.register_blueprint(votes_bp, url_prefix="/api/v1/votes")
    app.register_blueprint(results_bp, url_prefix="/api/v1/results")
    app.register_blueprint(settings_bp, url_prefix="/api/v1/settings")
    app.register_blueprint(audit_bp, url_prefix="/api/v1/audit")

    return app



if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=5000, debug=True)
